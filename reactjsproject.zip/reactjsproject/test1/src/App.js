
import './App.css'; 
function App() {
  return (
    <div className="text-center m-5-auto center">
   {/* &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; */}
   <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Signin</h3>
        <form action="/home">
            <p>
                <label>Name     : </label> 
                <input type="text" name="first_name" required />
            </p><br></br>
            <p>
                <label >Birthday:</label> 
                <input type="date" id="birthday" name="birthday"></input>
          
            </p><br></br>
            <p>
              <label for="language">Division:</label>
              <select name="language" id="language">
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
              </select>
          
            </p><br></br>
            <p>
              <label for="language">Gender:</label>
              <input type="radio" name="gender" value="male"/> Male
              <input type="radio" name="gender" value="female"/>  Female
            </p><br></br>
            <p>
            <label for="language">Class:</label>
                  <select name="language" id="language">
                    <option value="I">I</option>
                    <option value="II">II</option>
                    <option value="III">III</option>
                    <option value="IV">IV</option>
                    <option value="V">V</option>
                    <option value="VI">VI</option>
                    <option value="VII">VII</option>
                    <option value="VIII">VIII</option>
                    <option value="IX">IX</option>
                    <option value="X">X</option>
                    <option value="X11">X11</option>
                    <option value="X12">X12</option>
                  </select>
          
            </p>
            <p><br></br>
                <button id="sub_btn" type="submit">Submit</button>
            </p>
        </form>
    </div>
)

}

export default App;
